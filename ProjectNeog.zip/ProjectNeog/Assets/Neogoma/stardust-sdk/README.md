# stardust-sdk

Requires:
-Unity 2019.4.x or higher
-ARFoundation 4.0.8