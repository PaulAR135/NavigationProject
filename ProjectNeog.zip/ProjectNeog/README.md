# NavigationDemoRepo

Demo Repository for Navigation example.

This repository adresses changes made to the PathRenderer class in order to overwrite the default navigation arrows displayed, to use anything customized.
Also contains the example of a guide bot that guides users through their navigation targets in AR as well as using a UI arrow compass that adds to visual help in finding your way to your target.

Check out our [Documentation](https://neogoma.github.io/stardust-SDK-doc/#/).
